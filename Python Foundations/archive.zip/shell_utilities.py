import os
from os import path
import shutil

def main():
    if path.exists("sample.txt"):
        src = path.realpath("sample.txt")
        # dest = src + ".bkp"
        # shutil.copy(src,dest)
        # shutil.copystat(src,dest)
        #Rename the original
        # shutil.move()
        #os.rename("new_sample.txt","sample.txt",)
        root_dir, tail = path.split(src)
        shutil.make_archive("archive","zip",root_dir)
        


    


if __name__ == "__main__":
    main()