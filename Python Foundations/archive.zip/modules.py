import math

print("Square of 16 is - ", math.sqrt(16))
print("PI is - ", math.pi)